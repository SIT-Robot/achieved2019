#include "ros/ros.h"
#include <sit_robot_srv/ArmAction.h>
 
//heads for sending 
#include <stdio.h>      /*标准输入输出定义*/ 
#include <stdlib.h>     /*标准函数库定义*/
#include <unistd.h>     /*Unix 标准函数定义*/
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>      /*文件控制定义*/
#include <termios.h>    /*PPSIX 终端控制定义*/
#include <errno.h>      /*错误号定义*/
#include <string.h>
#include<iostream>
#include<math.h>
using namespace std;

//*********************************串口
#define FALSE -1
#define TRUE 0
#define LENGTH 8

int speed_arr[] = {B38400,B19200,B9600,B4800,B2400,B1200,B300,B38400,B19200,B9600,B4800,B2400,B1200,B300};
int name_arr[] = {38400,19200,9600,4800,2400,1200,300,38400,19200,9600,4800,2400,1200,300};
int fd;

int OpenDev(char *Dev);
void set_speed(int fd, int speed);
int set_Parity(int fd, int databits, int stopbits, int parity);
/****************LJP*********/
void dec2hex(int n,char *buf);
void ljp(char* ge, int n, int id[], int num[]);
char get[8] = { 0x77, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x88 };

//*************初始**************
char zero[8]={0x77,0x59,0xA3,0x58,0x79,0xA2,0x50,0x88};//初始姿态
/****************握手*********************/
char shake[8]={0x77,0x80,0x7E,0x90,0x70,0xA5,0x80,0x88};//握手
/****************baishou*************/
char PP1[8] = {0x77,0x05,0x98,0xCA,0x81,0xA7,0x95,0x88 };
char PP2[8] = {0x77,0xB4,0x98,0xCA,0x81,0xA7,0x95,0x88 };

/****************di-take*********************/
char gg1[8]={0x77,0x80,0xA3,0xB4,0xA4,0xA5,0x50,0x88};//一抬
char gg2[8]={0x77,0x80,0x85,0xB4,0xA9,0xA5,0x50,0x88};//二抬
char gg3[8]={0x77,0x80,0x85,0xA1,0xA9,0xA5,0x70,0x88};//
		//77 80 6E 82 A9 A5 70 88
char gg4[8]={0x77,0x80,0x85,0xA1,0x30,0xA5,0x70,0x88};//
char gg5[8]={0x77,0x80,0x85,0xA1,0x30,0xA5,0x90,0x88};//抓住
		//77 80 6E 82 30 A5 95 88
char gu6[8]={0x77,0x80,0x80,0xA1,0x30,0xA5,0x90,0x88};//上起

char go1[8]={0x77,0x6A,0x90,0x50,0xA0,0xA5,0x92,0x88};
char go2[8]={0x77,0x6A,0x9F,0x50,0xA0,0xA5,0x92,0x88};
/*********柜子********识别***/ 
char a1[8] = {0x77,0x80,0x58,0x75,0x32,0xA5,0x59,0x88 };

char a2[8] = {0x77,0x80,0x58,0x75,0x32,0xA5,0x90,0x88 };
char a3[8] = {0x77,0x80,0x55,0x75,0x32,0xA5,0x90,0x88 };

char a4[8] = {0x77,0x80,0x82,0xA5,0x32,0xA5,0x90,0x88 };

char a5[8] = {0x77,0x80,0x82,0xA5,0x32,0xA5,0x50,0x88 };

/****************gao-take*********************/
char ga1[8]={0x77,0x80,0xA3,0xB4,0xA4,0xA5,0x50,0x88};//一抬
char ga2[8]={0x77,0x80,0x83,0xB4,0xA9,0xA5,0x50,0x88};//二抬
char ga3[8]={0x77,0x80,0x83,0xA1,0xA9,0xA5,0x70,0x88};//
		//77 80 6E 82 A9 A5 70 88
char ga4[8]={0x77,0x80,0x83,0xA1,0x32,0xA5,0x70,0x88};//
char ga5[8]={0x77,0x80,0x83,0xA1,0x32,0xA5,0x90,0x88};//抓住
		//77 80 6E 82 30 A5 95 88
char ga6[8]={0x77,0x80,0x7A,0xA1,0x32,0xA5,0x90,0x88};//上起

char gao1[8]={0x77,0x6A,0x90,0x50,0xA0,0xA5,0x92,0x88};
char gao2[8]={0x77,0x6A,0x9F,0x50,0xA0,0xA5,0x92,0x88};

/****************放*********************/
char put1[8]={0x77,0x01,0x85,0x40,0xA9,0xA5,0x90,0x88};//高抬
char put2[8]={0x77,0x01,0x50,0x60,0x90,0xA5,0x90,0x88};//
char put3[8]={0x77,0x80,0x50,0x60,0x90,0xA5,0x90,0x88};//
char put4[8]={0x77,0x80,0x7E,0xA1,0x32,0xA5,0x90,0x88};//落物
		//0x77,0x80,0x83,0xA1,0x32,0xA5,0x90,0x88
char put5[8]={0x77,0x80,0x7E,0xA1,0x32,0xA5,0x65,0x88};//松手
char put6[8]={0x77,0x80,0x50,0xB4,0xA9,0xA5,0x65,0x88};//撤一
char put7[8]={0x77,0x80,0x50,0xB4,0xA4,0xA5,0x65,0x88};//撤二
char put8[8]={0x77,0x80,0x78,0xB4,0xA4,0xA5,0x50,0x88};
		//0x77,0x75,0xA3,0x58,0xA4,0xA5,0x50,0x88
/*
char put6[8]={0x77,0x75,0x50,0x50,0xB4,0xA5,0x65,0x88};//撤一
char put7[8]={0x77,0x01,0x50,0x50,0xB4,0xA5,0x65,0x88};//撤二
char put8[8]={0x77,0x01,0x78,0x50,0xB4,0xA5,0x50,0x88};
*/
char done[8]={0x77,0x75,0xA3,0x58,0x60,0xA5,0x50,0x88};//还原

/****************分部-take*********************/
char get14[8]={0x77,0x80,0xA3,0xB4,0xA9,0xA5,0x50,0x88};//一抬
char get24[8]={0x77,0x80,0x6A,0xB4,0xA9,0xA5,0x50,0x88};//二抬
char get34[8]={0x77,0x80,0x6E,0x85,0xA9,0xA5,0x70,0x88};//
char get44[8]={0x77,0x80,0x6E,0x80,0x30,0xA5,0x70,0x88};//
char get54[8]={0x77,0x80,0x6E,0x80,0x30,0xA5,0x92,0x88};//抓住
		//77 80 6E 82 30 A5 95 88
char gup64[8]={0x77,0x80,0x64,0x80,0x30,0xA5,0x92,0x88};//上起

char got14[8]={0x77,0x6A,0x90,0x50,0xA9,0xA5,0x92,0x88};
char got24[8]={0x77,0x6A,0x9F,0x50,0xA9,0xA5,0x92,0x88};
/*********/
/****************拿*********************/
char get1[8]={0x77,0x01,0x90,0x92,0xA9,0xA2,0x50,0x88};//一抬
char get2[8]={0x77,0x01,0x6A,0x92,0xA9,0xA5,0x50,0x88};//二抬
char get3[8]={0x77,0x80,0x6A,0x92,0xA9,0xA5,0x65,0x88};//
char get4[8]={0x77,0x80,0x6A,0x92,0xA9,0xA5,0x65,0x88};//
char gett1[8]={0x77,0x80,0x6A,0x92,0x50,0xA5,0x65,0x88};
char gett2[8]={0x77,0x80,0x6A,0x92,0x50,0xA5,0x95,0x88};//抓住
		//{0x77,0x6E,0x6A,0x92,0x7E,x  ,0x  ,0x88 };
char gotup[8]={0x77,0x80,0x64,0x90,0x60,0xA5,0x95,0x88};//上起
char got1[8]={0x77,0x01,0x64,0x90,0x90,0xA5,0x95,0x88};
char got2[8]={0x77,0x01,0x85,0x30,0x90,0xA5,0x95,0x88};//下一
char got3[8]={0x77,0x80,0x9F,0x50,0xA9,0xA5,0x95,0x88};//下二


		char q1[8] = {0x77,0x81,0x6B,0x0A,0xA6,0x49,0x50,0x88 };//0

		char q2[8] = {0x77,0x81,0x6B,0x0A,0xA6,0x49,0x90,0x88 };//1
		char q3[8] = {0x77,0x81,0x60,0x0A,0xA6,0x49,0x90,0x88 };//2

		char q4[8] = {0x77,0x81,0x60,0x0A,0xA6,0xA1,0x90,0x88 };//3
		char q5[8] = {0x77,0x81,0x40,0x0A,0xA6,0x49,0x90,0x88 };//
		char q6[8] = {0x77,0x81,0x6B,0x0A,0xA6,0x49,0x50,0x88 };//4
		char q7[8] = {0x77,0x81,0x6B,0x0A,0xA6,0x49,0x50,0x88 };//4
/****************分步-put*********************
char put201[8]={0x77,0x8A,0x40,0x10,0x1A,0x45,0x94,0x88};//高抬
char put202[8]={0x77,0x8A,0x40,0x10,0x40,0x45,0x94,0x88};//
char put203[8]={0x77,0x8A,0x40,0x10,0x40,0xA2,0x94,0x88};//
char put204[8]={0x77,0x8A,0x47,0x60,0x5a,0xA2,0x94,0x88};//落物
char put205[8]={0x77,0x8A,0x60,0x60,0x5a,0xA2,0x94,0x88};//松手
char put206[8]={0x77,0x8A,0x60,0x90,0x6a,0xA2,0x94,0x88};//撤一
char put207[8]={0x77,0x8A,0x75,0x90,0x6a,0xA2,0x94,0x88};//撤二
char put208[8]={0x77,0x8A,0x75,0x90,0x6a,0xA2,0x94,0x88};
char put209[8]={0x77,0x8A,0x75,0x90,0x6a,0xA2,0x75,0x88};
char put210[8]={0x77,0x8A,0x75,0xB4,0x10,0xA2,0x75,0x88};
char put211[8]={0x77,0x59,0x94,0xB4,0x10,0xA2,0x50,0x88};
char put212[8]={0x77,0x59,0x94,0x1A,0x61,0xA2,0x50,0x88};

/***************垃圾***********
char ut0[8]={0x77,0x8A,0x80,0xa5,0x70,0xa2,0x94,0x88};
char ut1[8]={0x77,0x8A,0x80,0xa5,0x70,0xa2,0x94,0x88};//高抬
char ut2[8]={0x77,0x8A,0x80,0xa5,0x70,0xa2,0x50,0x88};//
char ut3[8]={0x77,0x59,0xA3,0x58,0x75,0xA2,0x50,0x88};//

/****************倒***********************
char pour0[8]={0x77,0x01,0x50,0x60,0x50,0xA2,0x94,0x88};//
char pour1[8]={0x77,0x70,0x6F,0x7A,0x40,0xA2,0x94,0x88};
char pour2[8]={0x77,0x70,0x6F,0x7A,0x40,0x20,0x94,0x88};
char pour3[8]={0x77,0x70,0x6F,0x7A,0x40,0xA2,0x94,0x88};//
char pour4[8]={0x77,0x01,0x6F,0x7A,0x40,0xA2,0x94,0x88};
char pour5[8]={0x77,0x01,0x80,0x40,0x2A,0xA2,0x94,0x88};
char pour6[8]={0x77,0x80,0xAA,0x50,0x01,0xA2,0x94,0x88};*/

int handcatch(int type);

bool catchObj(	sit_robot_srv::ArmAction::Request  &req,	sit_robot_srv::ArmAction::Response &res);

int main(int argc, char **argv)
{
  	ros::init(argc, argv, "hand_action");
 	ros::NodeHandle armaction_nh("arm_action");

 	ros::ServiceServer service = armaction_nh.advertiseService("hand_action", catchObj);
//****串口初始化
  char dev[]  = "/dev/ttyUSB1"; //USB串口
  fd = OpenDev(dev);
  tcflush(fd, TCIFLUSH);
  set_speed(fd,115200);
  if (set_Parity(fd,8,1,'N') == FALSE)
  {
     printf("HAND=====>>> Set Parity Error\n");
     exit (0);
  }
  ROS_INFO("HAND=====>>> Device is open!");

//***
  ROS_INFO("HAND=====>>> Ready to catch.");

  ros::spin();
  close(fd);
  return 0;
}

bool catchObj(	sit_robot_srv::ArmAction::Request  &req,
         	sit_robot_srv::ArmAction::Response &res)
{
  res.isSuccess=handcatch(req.type);
  return true;
}


int handcatch(int type)
{
  int result=0;
  
  switch (type){
//case HAND_TYPE_CATCH_TWO_STEPS
//	case 0: 	cout<<"g0"<<endl;	write(fd, q1, LENGTH);	sleep(3);
	case 61:
		cout<<"q1"<<endl;	write(fd, a1, LENGTH);	sleep(5);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.61 complete!"<<endl;
		break; 
	case 62:
		cout<<"q2"<<endl;	write(fd, a2, LENGTH);	sleep(3);
		cout<<"g3"<<endl;	write(fd, a3, LENGTH);	sleep(3);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.62 complete!"<<endl;
		break; 

	case 63:
		cout<<"q4"<<endl;write(fd, a4, LENGTH);	sleep(5);
		cout<<"HAND=====>>> COMMAND NO.63 complete!"<<endl;
		result=1;
		break; 
	case 64:
		cout<<"q5"<<endl;write(fd, a5, LENGTH);	sleep(3);
	//	cout<<"落  "<<endl;	write(fd, q1, LENGTH);	sleep(4);
		cout<<"HAND=====>>> COMMAND NO.64 complete!"<<endl;
		result=1;
		break; 



	case 111:
		cout<<"q2"<<endl;	write(fd, q2, LENGTH);	sleep(4);
		cout<<"q3"<<endl;	write(fd, q3, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.111 complete!"<<endl;
		break; 
	case 222:

		cout<<"g4"<<endl;	write(fd, q4, LENGTH);	sleep(5);
		cout<<"q5"<<endl;write(fd, q5, LENGTH);	sleep(5);
		cout<<"q6"<<endl;write(fd, q6, LENGTH);	sleep(4);

		result=1;
		cout<<"HAND=====>>> COMMAND NO.222 complete!"<<endl;
		break; 

	case 333:
		cout<<"落  "<<endl;	write(fd, q1, LENGTH);	sleep(4);
		cout<<"HAND=====>>> COMMAND NO.333 complete!"<<endl;
		result=1;
		break; 


	case 911: { //int j = 3; int k[] = {2,4,6}; int l[] = {90,55,60};
			char get[8] = { 0x77, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x88 };
			char put[8] = { 0x77, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x88 };
			//ljp(get, j, k, l);
		    

			cout<<"get"<<endl;	write(fd, get, LENGTH);	sleep(4);
			int j = 3; int k[] = {2,4,6}; int l[] = {17,18,19};
			ljp(get,j,k,l);
		    cout<<"get"<<endl;	write(fd, get, LENGTH);	sleep(4);
		    break;}

	case 1:
		cout<<"g1"<<endl;	write(fd, gg1, LENGTH);	sleep(4);
		cout<<"g2"<<endl;	write(fd, gg2, LENGTH);	sleep(4);
		cout<<"g3"<<endl;	write(fd, gg3, LENGTH);	sleep(5);
		cout<<"gg4"<<endl;	write(fd, gg4, LENGTH);	sleep(5);
		cout<<"get5"<<endl;	write(fd, gg5, LENGTH);	sleep(4);
		cout<<"起"<<endl; 	write(fd, gu6, LENGTH);	sleep(3);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.1 complete!"<<endl;
		break; 
	case 2:

		cout<<"下一"<<endl;	write(fd, go1, LENGTH);	sleep(4);
		cout<<"下二"<<endl;	write(fd, go2, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.2 complete!"<<endl;
		break; 

	case 3:
		cout<<"落  "<<endl;	write(fd, put4, LENGTH);	sleep(4);
		cout<<"HAND=====>>> COMMAND NO.3 complete!"<<endl;
		break; 
	case 4:
		cout<<"松  "<<endl; 	write(fd, put5, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.4 complete!"<<endl;
		break; 
	case 5:
		cout<<"还原"<<endl;	write(fd, done, LENGTH);	sleep(4);
		cout<<"HAND=====>>> COMMAND NO.5 complete!"<<endl;
		result=1;
		break; 


	case 11:
		cout<<"get14"<<endl;	write(fd, get14, LENGTH);	sleep(4);
		cout<<"get24"<<endl;	write(fd, get24, LENGTH);	sleep(4);
		cout<<"get34"<<endl;	write(fd, get34, LENGTH);	sleep(3);
		cout<<"get44"<<endl;	write(fd, get44, LENGTH);	sleep(5);
		cout<<"get54"<<endl;	write(fd, get54, LENGTH);	sleep(4);
	/*	cout<<"一抬"<<endl;	write(fd, get1, LENGTH);	sleep(5);
		cout<<"二抬"<<endl;	write(fd, get2, LENGTH);	sleep(4);
		cout<<"三抬"<<endl;	write(fd, get3, LENGTH);	sleep(4);
		cout<<"落手"<<endl;	write(fd, get4, LENGTH);	sleep(4);
		cout<<"抓住1"<<endl;	write(fd, gett1, LENGTH);	sleep(6);
		cout<<"抓住2"<<endl;	write(fd, gett2, LENGTH);	sleep(3);*/
		cout<<"上起"<<endl; 	write(fd, gotup, LENGTH);	sleep(3);
		cout<<"下一"<<endl;	write(fd, got1, LENGTH);	sleep(4);
		cout<<"下二"<<endl;	write(fd, got2, LENGTH);	sleep(4);
		cout<<"下三"<<endl;	write(fd, got3, LENGTH);	sleep(5);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.1 complete!"<<endl;
		break; 
	case 12:
		cout<<"抬一"<<endl;	write(fd, put1, LENGTH);	sleep(4);
		cout<<"二  "<<endl;	write(fd, put2, LENGTH);	sleep(4);
		cout<<"三  "<<endl;	write(fd, put3, LENGTH);	sleep(5);
		cout<<"落物"<<endl;	write(fd, put4, LENGTH);	sleep(3);
		cout<<"松手"<<endl; 	write(fd, put5, LENGTH);	sleep(4);
		cout<<"撤一"<<endl;	write(fd, put6, LENGTH);	sleep(3);
		cout<<"撤二"<<endl;	write(fd, put7, LENGTH);	sleep(3);
		cout<<"撤三"<<endl;	write(fd, put8, LENGTH);	sleep(2);
		cout<<"还原"<<endl;	write(fd, done, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.2 complete!"<<endl;
		break;
	case 30:
		cout<<"抬一"<<endl;	write(fd, put1, LENGTH);	sleep(4);
		cout<<"二  "<<endl;	write(fd, put2, LENGTH);	sleep(4);
		cout<<"三  "<<endl;	write(fd, put3, LENGTH);	sleep(5);
		cout<<"落  "<<endl;	write(fd, put4, LENGTH);	sleep(3);
		cout<<"松  "<<endl; 	write(fd, put5, LENGTH);	sleep(4);
		cout<<"  一"<<endl;	write(fd, put6, LENGTH);	sleep(3);
		cout<<"  二"<<endl;	write(fd, put7, LENGTH);	sleep(3);
		cout<<"  三"<<endl;	write(fd, put8, LENGTH);	sleep(2);
		cout<<"还原"<<endl;	write(fd, done, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> COMMAND NO.3 complete!"<<endl;
		break; 
/*********************ZOO************************/
	case 66:
		cout<<"PP1"<<endl;	write(fd, PP1, LENGTH);		sleep(2);
		cout<<"PP2"<<endl;	write(fd, PP2, LENGTH);		sleep(3);
		
		cout<<"PP1"<<endl;	write(fd, PP1, LENGTH);		sleep(2);
		cout<<"PP2"<<endl;	write(fd, PP2, LENGTH);		sleep(3);
		
		cout<<"PP1"<<endl;	write(fd, PP1, LENGTH);		sleep(2);
		cout<<"PP2"<<endl;	write(fd, PP2, LENGTH);		sleep(3);
		
		cout<<"PP1"<<endl;	write(fd, PP1, LENGTH);		sleep(2);
		cout<<"PP2"<<endl;	write(fd, PP2, LENGTH);		sleep(3);
		break;
/*********************************************/
	  case 40:
		cout<<"get14"<<endl;	write(fd, get14, LENGTH);	sleep(4);
		cout<<"get24"<<endl;	write(fd, get24, LENGTH);	sleep(4);
		cout<<"get34"<<endl;	write(fd, get34, LENGTH);	sleep(4);
		cout<<"get44"<<endl;	write(fd, get44, LENGTH);	sleep(4);
		cout<<"get54"<<endl;	write(fd, get54, LENGTH);	sleep(4);
		cout<<"gup64"<<endl; 	write(fd, gup64, LENGTH);	sleep(6);
		result=1;
		break;
	  case 41:
		cout<<"got14"<<endl;	write(fd, got14, LENGTH);	sleep(3);
		cout<<"got24"<<endl;	write(fd, got24, LENGTH);	sleep(4);
		result=1;
		break;
/* 	  case 50:
		cout<<"gao1"<<endl;	write(fd, gao1, LENGTH);	sleep(4);
		cout<<"gao2"<<endl;	write(fd, gao2, LENGTH);	sleep(5);
		cout<<"gao3"<<endl;	write(fd, gao3, LENGTH);	sleep(4);
		cout<<"gao4"<<endl;	write(fd, gao4, LENGTH);	sleep(4);
		cout<<"gao5"<<endl;	write(fd, gao5, LENGTH);	sleep(4);
		cout<<"gao6"<<endl; 	write(fd, gao6, LENGTH);	sleep(4);
		break;
	  case 51:
		cout<<"got1"<<endl;	write(fd, got14, LENGTH);	sleep(4);
		cout<<"got2"<<endl;	write(fd, got24, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> type 51 complete!"<<endl;
		break; 

//放：
  	case 24:
		cout<<"put201"<<endl;	write(fd, put201, LENGTH);	sleep(4);
		cout<<"put202"<<endl;	write(fd, put202, LENGTH);	sleep(4);
		cout<<"put203"<<endl;	write(fd, put203, LENGTH);	sleep(4);
		cout<<"put204"<<endl;	write(fd, put204, LENGTH);	sleep(2);
		cout<<"put205"<<endl; 	write(fd, put205, LENGTH);	sleep(4);
		cout<<"put206"<<endl;	write(fd, put206, LENGTH);	sleep(2);
		cout<<"put207"<<endl;	write(fd, put207, LENGTH);	sleep(4);
		cout<<"put208"<<endl;	write(fd, put208, LENGTH);	sleep(4);
		cout<<"put209"<<endl;	write(fd, put209, LENGTH);	sleep(4);
		cout<<"put210"<<endl;	write(fd, put210, LENGTH);	sleep(4);
		cout<<"put211"<<endl;	write(fd, put211, LENGTH);	sleep(4);
		cout<<"put212"<<endl;	write(fd, put212, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> type 24 complete!"<<endl;
		break;
  	case 2:
		cout<<"put1"<<endl;	write(fd, put1, LENGTH);	sleep(4);
		cout<<"put2"<<endl;	write(fd, put2, LENGTH);	sleep(4);
		cout<<"put3"<<endl;	write(fd, put3, LENGTH);	sleep(4);
		cout<<"put4"<<endl;	write(fd, put4, LENGTH);	sleep(3);
		cout<<"put5"<<endl; 	write(fd, put5, LENGTH);	sleep(4);
		cout<<"put6"<<endl;	write(fd, put6, LENGTH);	sleep(3);
		cout<<"put7"<<endl;	write(fd, put7, LENGTH);	sleep(4);
		cout<<"put8"<<endl;	write(fd, put8, LENGTH);	sleep(4);
		cout<<"done"<<endl;	write(fd, done, LENGTH);	sleep(4);
		result=1;
		cout<<"HAND=====>>> type NO.2 complete!"<<endl;
		break;

//垃圾桶
  	case 444:
		cout<<"ut0"<<endl;	write(fd, ut0, LENGTH);	sleep(2);
		cout<<"ut1"<<endl;	write(fd, ut1, LENGTH);	sleep(4);
		cout<<"ut2"<<endl;	write(fd, ut2, LENGTH);	sleep(3);
		cout<<"ut3"<<endl;	write(fd, ut3, LENGTH);	sleep(4);
		break;
  	case 90:
		cout<<"put1"<<endl;	write(fd, put1, LENGTH);	sleep(5);
		cout<<"pour0"<<endl;	write(fd, pour0, LENGTH);	sleep(4);
		cout<<"pour1--4s"<<endl;	write(fd, pour1, LENGTH);	sleep(4);
		cout<<"pour2--8s"<<endl;	write(fd, pour2, LENGTH);	sleep(7);//倒出
		cout<<"pour3--5s"<<endl;	write(fd, pour3, LENGTH);	sleep(5);
		cout<<"pour4--5s"<<endl;	write(fd, pour4, LENGTH);	sleep(5);
		cout<<"pour5--4s"<<endl;	write(fd, pour5, LENGTH);	sleep(4);
		cout<<"pour6--4s"<<endl;	write(fd, pour6, LENGTH);	sleep(4);
		cout<<"HAND=====>>> type NO.3 complete!"<<endl;
		break;*/

	case 99:
		cout<<"握手"<<endl;	write(fd, shake, LENGTH);	sleep(8);
		cout<<"HAND=====>>> COMMAND shake complete!"<<endl;
		break;
	case 1000:
		cout<<"初始"<<endl;	write(fd, zero, LENGTH);	sleep(5);
		cout<<"HAND=====>>> COMMAND original complete!"<<endl;
		break;
	default:
		break;
  }
  return result;

}
/********16进制转换********/ 
void dec2hex(int n,char *buf)
{
	char t;
	char *p=buf;
	while(n)
	{
		t=n%16;
		*buf++=t<10?t+'0':t-10+'A';
		n/=16;
	}
	*buf++='x';
	*buf++='0';
	*buf--='\0';
	while(p<buf)
	{
		t=*p;
		*p=*buf;
		*buf=t;
		++p;
		--buf;
	}
}

/********赋值********/ 
void ljp(char* ge, int n, int id[], int num[])		//n:改动个数，i：序号， num:数值 
{
	int j;
	for (j = 1; j <= n ; j++)
	{
		j -= 1;
		int k;
		//char *temp = new char[4];
		char temp[4];
		int res = 0;
		dec2hex(num[j], temp);
		if (temp[2] < 48 || temp[2]>57) res += (temp[2] - 55)*16;
		else res+=(temp[2]-48)*16;
		if (temp[3] < 48 || temp[3]>57) res += temp[3] - 55;
		else res += temp[3]-48;
		for (k = 0; k < id[j]; k++)
		{
			ge++;
		}

		*ge = res;

		for (; k > 0; k--)
		{
			ge--;
		}
		//delete temp;
		//temp = NULL;
		j += 1;
	}
}
void set_speed(int fd, int speed)
{
	unsigned int   i;
	int   status;
	struct termios   Opt;
	tcgetattr(fd, &Opt);
	for ( i= 0;  i < sizeof(speed_arr) / sizeof(int);  i++)
	{
	      if  (speed == name_arr[i])
	      {
	            tcflush(fd, TCIOFLUSH);
	            cfsetispeed(&Opt, speed_arr[i]);
	            cfsetospeed(&Opt, speed_arr[i]);
	            status = tcsetattr(fd, TCSANOW, &Opt);
	            if  (status != 0)
		    {
		            perror("tcsetattr fd");
		            return;
	            }
	            tcflush(fd,TCIOFLUSH);
	      }
	}
}

/**
 * *@brief   设置串口数据位，停止位和效验位
 * *@param  fd     类型  int  打开的串口文件句柄
 * *@param  databits 类型  int 数据位   取值 为 7 或者8
 * *@param  stopbits 类型  int 停止位   取值为 1 或者2
 * *@param  parity  类型  int  效验类型 取值为N,E,O,S
 * */
int set_Parity(int fd,int databits,int stopbits,int parity)
{
	struct termios options;
	if  ( tcgetattr( fd,&options)  !=  0)
	{
		perror("SetupSerial 1");
		return(FALSE);
	}
	options.c_cflag &= ~CSIZE;
	switch (databits) /*设置数据位数*/
	{
	case 7:
		options.c_cflag |= CS7;
		break;
	case 8:
		options.c_cflag |= CS8;
		break;
	default:
		fprintf(stderr,"Unsupported data size\n");
		return (FALSE);
	}
	switch (parity)
	{
	case 'n':
	case 'N':
		options.c_cflag &= ~PARENB;   /* Clear parity enable */
		options.c_iflag &= ~INPCK;     /* Enable parity checking */
		break;
	case 'o':
	case 'O':
		options.c_cflag |= (PARODD | PARENB); /* 设置为奇效验*/
		options.c_iflag |= INPCK;             /* Disnable parity checking */
		break;
	case 'e':
	case 'E':
		options.c_cflag |= PARENB;     /* Enable parity */
		options.c_cflag &= ~PARODD;   /* 转换为偶效验*/
		options.c_iflag |= INPCK;       /* Disnable parity checking */
		break;
	case 'S':
	case 's':  /*as no parity*/
		options.c_cflag &= ~PARENB;
		options.c_cflag &= ~CSTOPB;break;
	default:
		fprintf(stderr,"Unsupported parity\n");
		return (FALSE);
	}
	/* 设置停止位*/
	switch (stopbits)
	{
	case 1:
		options.c_cflag &= ~CSTOPB;
		break;
	case 2:
		options.c_cflag |= CSTOPB;
		break;
   	default:
     	        fprintf(stderr,"Unsupported stop bits\n");
		return (FALSE);
	}
	/* Set input parity option */
	if (parity != 'n')
		options.c_iflag |= INPCK;
	tcflush(fd,TCIFLUSH);
	options.c_cc[VTIME] = 150; /* 设置超时15 seconds*/
	options.c_cc[VMIN] = 0; /* Update the options and do it NOW */
	if (tcsetattr(fd,TCSANOW,&options) != 0)
	{
		perror("SetupSerial 3");
		return (FALSE);
	}
	return (TRUE);
}

/**********************************************************************
 * 代码说明：使用usb串口测试的，发送的数据是字符，
 * 但是没有发送字符串结束符号，所以接收到后，后面加上了结束符号。
&nbsp; * **********************************************************************/
/*********************************************************************/

int OpenDev(char *Dev)
{
	int	fd = open(Dev, O_RDWR);         //| O_NOCTTY | O_NDELAY
	if (-1 == fd)
	{
		perror("HAND=====>>> Can't Open Serial Port");
		return -1;
	}
	else
		return fd;
}

