# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/stamdordli/catkin_ws/src/face_recognition-catkin/msg/FRClientGoal.msg;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg/FaceRecognitionAction.msg;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg/FaceRecognitionActionGoal.msg;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg/FaceRecognitionActionResult.msg;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg/FaceRecognitionActionFeedback.msg;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg/FaceRecognitionGoal.msg;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg/FaceRecognitionResult.msg;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg/FaceRecognitionFeedback.msg"
services_str = ""
pkg_name = "face_recognition"
dependencies_str = "std_msgs;actionlib_msgs"
langs = "gencpp;genlisp;genpy"
dep_include_paths_str = "face_recognition;/home/stamdordli/catkin_ws/src/face_recognition-catkin/msg;face_recognition;/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/face_recognition/msg;std_msgs;/opt/ros/indigo/share/std_msgs/cmake/../msg;actionlib_msgs;/opt/ros/indigo/share/actionlib_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/indigo/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
