# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/include".split(';') if "/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "message_runtime;roscpp;std_msgs;actionlib;rospy;roslib;actionlib_msgs;cv_bridge;image_transport".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "face_recognition"
PROJECT_SPACE_DIR = "/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel"
PROJECT_VERSION = "0.0.0"
