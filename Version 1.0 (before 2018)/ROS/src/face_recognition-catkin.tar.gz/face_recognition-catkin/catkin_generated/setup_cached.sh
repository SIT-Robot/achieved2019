#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel:$CMAKE_PREFIX_PATH"
export CPATH="/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/include:$CPATH"
export LD_LIBRARY_PATH="/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/lib:/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/lib/x86_64-linux-gnu:/home/stamdordli/catkin_ws/devel/lib/x86_64-linux-gnu:/opt/ros/indigo/lib/x86_64-linux-gnu:/home/stamdordli/catkin_ws/devel/lib:/opt/ros/indigo/lib"
export PATH="/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/bin:$PATH"
export PKG_CONFIG_PATH="/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/lib/pkgconfig:/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/lib/x86_64-linux-gnu/pkgconfig:/home/stamdordli/catkin_ws/devel/lib/x86_64-linux-gnu/pkgconfig:/opt/ros/indigo/lib/x86_64-linux-gnu/pkgconfig:/home/stamdordli/catkin_ws/devel/lib/pkgconfig:/opt/ros/indigo/lib/pkgconfig"
export PYTHONPATH="/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/stamdordli/catkin_ws/src/face_recognition-catkin/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/stamdordli/catkin_ws/src/face_recognition-catkin:$ROS_PACKAGE_PATH"