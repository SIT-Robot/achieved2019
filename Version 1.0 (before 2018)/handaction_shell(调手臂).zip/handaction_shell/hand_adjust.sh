#!/bin/bash
#echo -e "\033[33m 阿斯顿 \033[0m"
#更改串口权限
echo -e "\033[33m本程序一运行根本停不下来 \033[0m"
echo -e "\033[31m所以趁现在确定两根串口线都插♂ 好了 \033[0m"
echo -e "\033[33m然后...... \033[0m"
echo -e "\033[33m由于某种神奇的原因 \033[0m"
echo -e "\033[31m请在cutecom运行后，打开 /dev/ttyUSB1，再退出 \033[0m"
echo -e "\033[33m更改串口权限需要输入密码： \033[0m"

sudo chmod 777 /dev/ttyUSB0
sudo chmod 777 /dev/ttyUSB1
sudo cutecom
echo -e "\033[31m串口权限更改完毕 \033[0m"
echo ""

#结束已开启的手臂服务
sudo killall hand_action
echo -e "\033[31m手臂进程结束 \033[0m"
echo ""

#备份原始的手臂源代码
backup_name="hand_action_"$(date +%Y_%m_%d_%H:%M)".cpp"
cd ~/catkin_ws/src/sit_robot_common/hand_action/src/
test -d backup
res=$?
if [ 0 -ne ${res} ];then
	mkdir backup
	echo "备份目录不存在，已建立"
fi
cp -f hand_action.cpp ./backup/$backup_name
echo -e "\033[33m"原始文件已备份为："${backup_name} \033[0m"
echo ""

#使用gedit修改手臂源代码 & 载入手臂调试工具
cd ~/handaction_shell
gedit ~/catkin_ws/src/sit_robot_common/hand_action/src/hand_action.cpp & ./UartSender.sh
echo -e "\033[31m手臂源代码修改完毕 \033[0m"

#源代码关闭后进行编译
./build.sh
./hand_test.sh


