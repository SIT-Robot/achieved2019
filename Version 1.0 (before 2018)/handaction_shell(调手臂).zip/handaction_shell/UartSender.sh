#!/bin/bash
echo "运行手臂调试工具"
sudo ./UartSender
