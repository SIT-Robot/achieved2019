#!/bin/bash
echo starting roscore
roscore
