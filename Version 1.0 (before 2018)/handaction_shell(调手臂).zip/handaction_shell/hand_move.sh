#!/bin/bash
sleep 3

echo ""
echo -e "\033[33m手臂准备完毕 \033[0m"
echo -e "\033[31m请输入动作序号,如(11): \033[0m\c" 
read action_num


#写入文件
echo \#!/bin/bash>run.sh
echo rosservice call /arm_action/hand_action \"type: ${action_num}\" >>run.sh
chmod +x run.sh

#调用程序，手臂开始动作
./run.sh

#判断再次执行/结束程序
echo ""
echo -e "\033[31m动作运行完毕\033[0m"
echo -e "\033[31m执行下一组动作？(Y/N)\033[0m\c"
read If_Again


if [ "n" = ${If_Again} ];then
    killall hand_action
    killall roscore
    sleep 1
    echo -e "\033[33m动作结束\033[0m"
    echo -e "\033[33mroscore与hand_action进程已结束\033[0m"
    exit 1
elif [ "N" = ${If_Again} ];then
    killall hand_action
    killall roscore
    sleep 1
    echo -e "\033[33m动作结束\033[0m"
    echo -e "\033[33mroscore与hand_action进程已结束\033[0m"
    exit 1
else
    ./hand_move.sh
fi
