#!/bin/bash
#roscore立即启动
#rosrun延时1秒启动
#rosservice 延时2秒启动
./roscore.sh &
./rosrun.sh &
./hand_move.sh

