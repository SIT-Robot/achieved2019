#!/bin/bash
sleep 1
echo starting rosrun hand_action
rosrun hand_action hand_action
