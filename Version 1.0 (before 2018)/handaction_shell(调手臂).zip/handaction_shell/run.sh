#!/bin/bash
rosservice call /arm_action/hand_action "type: 14"
