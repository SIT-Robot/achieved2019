#!/bin/bash
#源代码关闭后进行编译
cd ~/catkin_ws/
catkin_make
echo -e "\033[31m新项目编译完成 \033[0m"
echo ""

cd ~/handaction_shell
